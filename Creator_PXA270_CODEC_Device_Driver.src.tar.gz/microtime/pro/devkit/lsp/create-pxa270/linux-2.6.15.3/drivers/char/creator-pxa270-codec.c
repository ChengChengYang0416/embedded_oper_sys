// --------------------------------------------------------------------
//
//   Title     :  creator-pxa270-codec.c
//             :
//   Library   :
//             :
//   Developers:  MICROTIME MDS group
//             :
//   Purpose   :  Non Interrupt (Polling)IIC bus for CODEC (TLV320AIC14)
//             :
//   Limitation:
//             :
//   Note      :
//             :
// --------------------------------------------------------------------
//   modification history :
// --------------------------------------------------------------------
//   Version| mod. date: |
//   Vx.xx  | mm/dd/yyyy |
//   V1.00  | 06/06/2006 | First release
//   V1.01  | 06/19/2006 |              
// --------------------------------------------------------------------
// --------------------------------------------------------------------
//
// Note:
//
//       MICROTIME COMPUTER INC.
//
//
/*************************************************************************
Include files
*************************************************************************/
#include <linux/config.h> 
#include <linux/kernel.h>
#include <linux/module.h> 

#include <linux/cdev.h>
#include <linux/delay.h>
#include <linux/fcntl.h>
#include <linux/fs.h>
#include <linux/init.h>
#include <linux/interrupt.h>
#include <linux/kmod.h>
#include <linux/major.h>
#include <linux/slab.h>
#include <linux/string.h>
#include <linux/timer.h>
#include <linux/utsname.h>
#include <linux/version.h>
#include <linux/i2c.h>
#include <linux/i2c-dev.h>
#include <asm/irq.h>

#include <asm/mach/irq.h>
#include <asm/system.h>
#include <asm/uaccess.h>

#include <asm/arch/lib/creator_pxa270_core.h>
#include <asm/arch/lib/creator_pxa270_codec.h>



/*************************************************************************
Constant define
*************************************************************************/

/* ****** Debug Information ******************************************** */
#define DEBUG
#ifdef DEBUG
#define MSG(string, args...) printk("<1>%s(), line=%d, " string, __FUNCTION__, __LINE__, ##args)
#else   
#define MSG(string, args...)
#endif



/* ****** Module Information ******************************************* */
#define	MAJOR_NUM			CODEC_MAJOR_NUM
#define MAX_MINORS          1

#define MODULE_VERSION_INFO	"1.01"
#define MODULE_NAME			"CODEC_CREATOR"
#define COPYRIGHT			"Copyright (C) 2006, Microtime Computer Inc."
#define MODULE_AUTHOR_STRING		"Microtime Computer Inc."
#define MODULE_DESCRIPTION_STRING	"Creator CODEC module"



/* ****** IRQ information ********************************************* */
#define CODEC_IRQ_NO		CREATOR_IO_XIRQ2_IRQ
#define CODEC_IRQ_BIT_NO	6



/*************************************************************************
for I2C
*************************************************************************/
#define SLAVE_ADDR  0x40



/*************************************************************************
Function prototypes
*************************************************************************/
static int  __init codec_HW_init(void);
static int 	iic_init(void);
static int 	IICWriteAIC(U8 Addr, U8 Data);



/*************************************************************************
Variable define
*************************************************************************/
static char* g_codec_irq_id = "creator TLV320AIC12"; /* global CODEC id for irq */
static struct i2c_adapter *adapter;
/* ************************************************************************** */




static int 
iic_init (void)
{
        adapter = i2c_get_adapter(0);
    
	    return (adapter ? 0 : -1);
}
/* ************************************************************************** */



static int 
IICReadAIC (U8 Addr, unsigned char *buf, unsigned char len)
{
        unsigned char addr[1] = { Addr };
        struct i2c_msg msgs[2] = {
	        {SLAVE_ADDR, 0, 1, addr},
	        {SLAVE_ADDR, I2C_M_RD, 1, buf}
        };
        int ret = -EIO;       

        //MSG("adr=%d, buf=%p, len=%d\n",  Addr, buf, len);

        if (!buf) {
            ret = -EINVAL;
            goto done;
        }
  
        ret = i2c_transfer(adapter, msgs, 2);
        if (ret == 2) {
            ret = 0;
        }

done:
	    return ret;
}	
/* ************************************************************************** */



static int 
IICWriteAIC (U8 Addr, U8 Data)
{
        struct i2c_msg wr;    
        int            ret = 0;
        unsigned char  _data[16];
       
        _data[0] = Addr;
        _data[1] = Data;

        wr.addr = SLAVE_ADDR;
        wr.flags = 0;
        wr.len = 2;
        wr.buf = _data;

        ret = i2c_transfer(adapter, &wr, 1);
        if (ret == 1) {
            ret = 0;
        }
       
        return (ret);
}
/* ************************************************************************** */



/*************************************************************************
Constant define for TLV320AIC12
*************************************************************************/
#define MAX_BUF_SIZE   0x20000

extern creator_io_t creator_io ;

static U32 	aic_buf_size;
//static U32 	record_count;
static U16 	*aic_record_ptr, *aic_play_ptr, *aic_buf_ptr;
static U16 	codec_status = CODEC_STATUS_STOP;
static U16 	aic_in, aic_out;
static U16 	AIC_dummy;
//static U8	mic_gain, spk_gain, sampling_rate;
static U8 	aic_record_on, aic_play_on;
static U8	byIsAICWorking ;
/* ************************************************************************** */



/////////////////////////////////////////////////////////////////////////////////////////
//interrupt callback function
/////////////////////////////////////////////////////////////////////////////////////////
static irqreturn_t 
IRQ_AIC (int irq, void *dev_id, struct pt_regs *regs) 
{
        U16 data_in;
        
        IO_REG2 = (1<<8);
        data_in = CODEC_DATA;	//get data and release IRQ2                
        if (aic_record_on == OK) {
            if (aic_record_ptr != 0) {
                *aic_record_ptr = data_in;
                if (aic_record_ptr < (UI *)(aic_buf_size+aic_buf_ptr)) {
                    aic_record_ptr++;
                }
            }
        }
        if (aic_play_on == OK) {
            if (aic_play_ptr != 0) {
                if (aic_play_ptr >= aic_record_ptr) {
                    aic_play_ptr = aic_buf_ptr;
                }
                CODEC_DATA = *aic_play_ptr++;
            }
            else {
                CODEC_DATA = 0;
            }
        }   
        IO_REG2 = (0<<8);       
        return (IRQ_HANDLED);
}
/* ************************************************************************** */



static int 
IRQ_REQUEST (void)
{
        int result ;
    
        if (byIsAICWorking == 0){
            //Setup the IRQ2 entry point for CODEC
            result = request_irq(CODEC_IRQ_NO, IRQ_AIC, 0, g_codec_irq_id, NULL);
            if (result < 0){
                printk("request_irq %x, and IRQ_AIC function fail\n\r", CODEC_IRQ_NO);
                return (result);
            }
            byIsAICWorking = 1;           
            //enable_irq(CODEC_IRQ_NO);
        }
        else{ 
            enable_irq(CODEC_IRQ_NO);         
        }
       AIC_dummy = CODEC_DATA;	      
       return (0);
}
/* ************************************************************************** */



static void 
IRQ_FREE (void)
{
        if (byIsAICWorking == 1){
            //disable IRQ
            disable_irq(CODEC_IRQ_NO);
            //free interrupt
            free_irq(CODEC_IRQ_NO, NULL);    	
        }
}
/* ************************************************************************** */



/*************************************************************************
Utlitiy functions 
*************************************************************************/
static void 
CODEC_malloc (UL size)
{
        aic_buf_size = size;
        aic_buf_ptr = (UI *)(kmalloc(size, GFP_KERNEL));
        aic_record_ptr = aic_buf_ptr;
        if (!aic_buf_ptr){
            printk("kmalloc function return fail!\n\r");		
        }    
}
/* ************************************************************************** */



static void 
CODEC_mfree (void)
{
        aic_buf_size = 0;
        kfree(aic_buf_ptr);
        aic_buf_ptr = 0;
}
/* ************************************************************************** */



static void 
CODEC_Record_Start (void)
{
        if (aic_record_on == OK)
            return ;
           
        if (IRQ_REQUEST() < 0){
            printk("Codec Record start Alloc IRQ Error\n");
            return ;
        }

        //ADC_in -> buffer++
        if (aic_record_on != OK) {
            codec_status = CODEC_STATUS_RECORD;
            aic_record_ptr = aic_buf_ptr;
            aic_record_on = OK;        
        }
}
/* ************************************************************************** */



static void 
CODEC_Record_Stop (void)
{      
        //ADC_in -> null
       
        if (aic_record_on){

            //0000 -> DAC_out        
            if (codec_status != CODEC_STATUS_STOP)
                disable_irq(CODEC_IRQ_NO);                
            
            codec_status = CODEC_STATUS_STOP;
            aic_record_on = UM;
        }           
}
/* ************************************************************************** */



static void 
CODEC_Play_Start (void)
{
        unsigned long flags;
            
        if (aic_play_on == OK)
            return ;
           
        if (IRQ_REQUEST() < 0){
             return ;
        } 

        //buffer++ -> DAC_out
        if (aic_play_on != OK) {    
            codec_status = CODEC_STATUS_PLAY;
            aic_play_ptr = aic_buf_ptr;
            aic_play_on = OK;
            
            spin_lock_irqsave(&creator_io.creator_lock, flags);              
            creator_io.cpld_ctrl |= 0x02;	//AIC_ON : Speaker OFF
            CPLD_CTRL = creator_io.cpld_ctrl;
            spin_unlock_irqrestore(&creator_io.creator_lock, flags);             
        }    
}
/* ************************************************************************** */



static void 
CODEC_Play_Stop (void)
{ 
        unsigned long flags;    
        //0000 -> DAC_out
        if (aic_play_on){
            if (codec_status != CODEC_STATUS_STOP)
                disable_irq(CODEC_IRQ_NO);            
       
            codec_status = CODEC_STATUS_STOP;
            aic_play_on = UM;
            
            spin_lock_irqsave(&creator_io.creator_lock, flags); 
            creator_io.cpld_ctrl &= 0xfd;	//AIC_OFF : Speaker OFF
            CPLD_CTRL = creator_io.cpld_ctrl;
            spin_unlock_irqrestore(&creator_io.creator_lock, flags);            
        }           
}
/* ************************************************************************** */



/*************************************************************************
Proper Module Functions
*************************************************************************/
static int 
drv_codec_open ( struct inode *inode, struct file *file ) 
{
        codec_status = CODEC_STATUS_STOP;
        CODEC_malloc(MAX_BUF_SIZE);          

        return (0);
}
/* ************************************************************************** */



static int 
drv_codec_release ( struct inode *inode, struct file *file ) 
{
        //free interrupt and buffer	
        CODEC_Record_Stop();
        CODEC_Play_Stop();
        CODEC_mfree();             

        return (0);
}
/* ************************************************************************** */



static  ssize_t  
drv_codec_read (struct file *filep, char *buf, size_t count, loff_t *ppos)
{
        if (codec_status != CODEC_STATUS_STOP)
            return -1;
        if(count >  MAX_BUF_SIZE)
            count = MAX_BUF_SIZE;
        copy_to_user((UC*)buf, (UC*)aic_buf_ptr, count);
    
       return (count);
}
/* ************************************************************************** */



static ssize_t 
drv_codec_write (struct file *filep, const char *buf, size_t count, loff_t *ppos)
{
        if (codec_status != CODEC_STATUS_STOP)
            return -1;
        if (count >  MAX_BUF_SIZE)
            count = MAX_BUF_SIZE;

        copy_from_user((UC*)aic_buf_ptr, (UC*)buf, count);

        return (count);
}
/* ************************************************************************** */



static int 
drv_codec_ioctl (struct inode *inode, struct file *filep, unsigned int command, unsigned long argAddress)
{
	    int                 rc = 0;	
	        
        if (_IOC_TYPE(command) != CODEC_IOCTL_MAGIC){
            printk("_IOC_TYPE(%x, %d) != CODEC_IOCTL_MAGIC", command, command);
            return (-ENOTTY);
        }	
        
        switch (command) {
        case IOCTL_PLAY_START :		 // �}�l���� 
            //printk(" call CODEC_Play_Start()\n\r");
            CODEC_Play_Start();
            break;						
        case IOCTL_PLAY_STOP :		 // �������� 
            //printk(" call CODEC_Play_Stop()\n\r");
            CODEC_Play_Stop();
            break;						
        case IOCTL_RECORD_START :	 // �}�l���� 
            //printk(" call CODEC_Record_Start()\n\r");
            CODEC_Record_Start();
            break;						
        case IOCTL_REOCRD_STOP :	 // �������� 
            //printk(" call CODEC_Record_Stop()\n\r");
            CODEC_Record_Stop();
            break;
        default:
            //printk("no match cmd \n\r");
            break;
        }
        return (rc);
}                        
/* ************************************************************************** */



static struct file_operations drv_code_fops = {	
	read:		drv_codec_read,
	write:		drv_codec_write,
	ioctl:		drv_codec_ioctl,
	open:		drv_codec_open,
	release:	drv_codec_release
};



static struct cdev codec_cdev = {
	.kobj	=	{.name = "creator codec", },
	.owner	=	THIS_MODULE,
};
/* ************************************************************************** */



static int 
codec_HW_init (void)
{
        unsigned long flags;  
       
        //for initial something
        if (iic_init() < 0)
            return (-1);

        //CODEC chip initialization (8K Sampling rate)
        IICWriteAIC(4, 0x8a);	//CR4 : M=10
        IICWriteAIC(4, 0x42);	//CR4 : N=4, P=2
        IICWriteAIC(2, 0xa0);	//CR2 : TURBO MODE
        IICWriteAIC(3, 0x01);	//CR3 : Normal
        IICWriteAIC(5, 0x34);	//CR5 : A2D Gain = +10dB
        IICWriteAIC(5, 0x56);	//CR5 : D2A Gain = -20dB
        IICWriteAIC(5, 0xbb);	//CR5 : A2D Preamp = 24dB
        IICWriteAIC(6, 0x9a);	//CR6 : 

        //Variables initialization
        aic_record_on = UM;
        aic_play_on = UM;
        aic_record_ptr = (UI *)0x000000;
        aic_play_ptr = (UI *)0x000000;
        aic_buf_size = 0;

        //Dummy read for INT2=1
        aic_in = CODEC_DATA;	

        //Turn OFF the CODEC function : Speaker OFF
      
        spin_lock_irqsave(&creator_io.creator_lock, flags);      
        creator_io.cpld_ctrl &= 0xfd;		
        CPLD_CTRL = creator_io.cpld_ctrl;
        spin_unlock_irqrestore(&creator_io.creator_lock, flags);   

        byIsAICWorking = 0;
        
        return (0);
}
/* ************************************************************************** */



/*************************************************************************
initial and cleanup
*************************************************************************/
static int __init 
create_pxa270_codec_init (void) 
{
        struct  cdev   *pcdev;     
        dev_t   devno;    
        int	    error;	
                   

        if (codec_HW_init() < 0){
            printk("<1>%s: can't get I2C adapter \n", MODULE_NAME);	    
            return (-EBUSY);
        }    

        //register chrdev	
	    devno = MKDEV(MAJOR_NUM, 0);	    
        if (register_chrdev_region(devno, MAX_MINORS, MODULE_NAME)){    
            printk("<1>%s: can't get major %d\n", MODULE_NAME, MAJOR_NUM);			    
            return (-EBUSY);
        }		    
        pcdev = &codec_cdev;		    
    	cdev_init(pcdev, &drv_code_fops);
	    pcdev->owner = THIS_MODULE;
    
    	
        /* Register lcdtxt as character device */
        error = cdev_add(pcdev, devno, MAX_MINORS);
        if (error) {
            kobject_put(&pcdev->kobj);
            unregister_chrdev_region(devno, MAX_MINORS);

            printk(KERN_ERR "error register %s device\n", MODULE_NAME);
            
            return (-EBUSY);
        }        
        printk("<1>%s: Version : %s %s\n", MODULE_NAME, MODULE_VERSION_INFO, COPYRIGHT);           	

        return (0);
}
/* ************************************************************************** */



static void __exit 
create_pxa270_codec_cleanup (void) 
{
        //free interrupt and buffer		
        IRQ_FREE();	
        CODEC_mfree();	

        //unregister chrdev 
        cdev_del(&codec_cdev);
       	unregister_chrdev_region(MKDEV(MAJOR_NUM, 0), MAX_MINORS);
}
/* ************************************************************************** */



//////////////////////////////////////////////////////////////////////////
module_init( create_pxa270_codec_init );
module_exit( create_pxa270_codec_cleanup );

MODULE_AUTHOR(MODULE_AUTHOR_STRING);
MODULE_DESCRIPTION(MODULE_DESCRIPTION_STRING);

