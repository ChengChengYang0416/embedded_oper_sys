/*
 * codec driver for Creator
 *
 *
 * Copyright (C) 2004 by Microtime Computer Inc.
 *
 * Linux kernel version history:
 * Version   : 1.00
 * History
 *   1.0.0 : Programming start (03/05/2004) -> SOP
 *
 */
#ifndef _CREATOR_S3C4510_CODEC_H_ 
#define _CREATOR_S3C4510_CODEC_H_ 


#include <linux/config.h>
#include <asm/arch/lib/def.h>


#if defined(__linux__)
#include <asm/ioctl.h>		/* For _IO* macros */
#define CODEC_IOCTL_NR(n)	     		_IOC_NR(n)
#elif defined(__FreeBSD__)
#include <sys/ioccom.h>
#define CODEC_IOCTL_NR(n)	     		((n) & 0xff)
#endif

#define CODEC_MAJOR_NUM		121
#define CODEC_IOCTL_MAGIC	CODEC_MAJOR_NUM
#define CODEC_IO(nr)		_IO(CODEC_IOCTL_MAGIC,nr)
#define CODEC_IOR(nr,size)	_IOR(CODEC_IOCTL_MAGIC,nr,size)
#define CODEC_IOW(nr,size)	_IOW(CODEC_IOCTL_MAGIC,nr,size)
#define CODEC_IOWR(nr,size)	_IOWR(CODEC_IOCTL_MAGIC,nr,size)


//codec command
#define CODEC_QUIT          0   //���}codec����
#define CODEC_RECORD_START  1   //�}�l����
#define CODEC_PLAY_START    2   //�}�l����
#define CODEC_REC_PLAY_STOP 3   //�������/����

//codec status
#define CODEC_STATUS_STOP     0  //����A
#define CODEC_STATUS_PLAY     1  //���񪬺A
#define CODEC_STATUS_RECORD   2  //�������A

/***********************************************************************
	specific ioctls
************************************************************************/
#define IOCTL_PLAY_START	CODEC_IO(0x00)
#define IOCTL_PLAY_STOP	   	CODEC_IO(0x01)
#define IOCTL_RECORD_START	CODEC_IO(0x10)
#define IOCTL_REOCRD_STOP	CODEC_IO(0x11)





#endif /*_CREATOR_S3C2410_CODEC_H_ */

